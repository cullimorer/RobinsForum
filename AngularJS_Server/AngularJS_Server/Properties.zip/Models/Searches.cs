﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AngularJS_Server.Models
{
    public class Search
    {
        public int Id { get; set; }
        public string SearchTerm { get; set; }
    }
}